// data.js (DATA ONLY)

const products = [
    {
        name: "Sony WH-1000XM5",
        price: "RS460000",
        image: "images/hp1.jpg",
        category: "headphones",
        id: 1
    },
    {
        name: "Bose QuietComfort 45",
        price: "RS32000",
        image: "images/hp2.jpg",
        id: 2,
        category: "headphones"
    },
    {
        name: "JBL Tune 760NC",
        price: "RS14000",
        image: "images/hp3.jpg",
        id: 3,
        category: "headphones"
    },
    {
        name: "Beats Studio 3",
        price: "RS18000",
        image: "images/hp4.jpg",
        id: 4,
        category: "headphones"
    },
    {
        name: "Sennheiser HD 450BT",
        price: "RS21000",
        image: "images/hp5.jpg",
        id: 5,
        category: "headphones"
    },

    // 🖱️ MOUSE
    {
        name: "Bloody A320M",
        price: "RS6000",
        image: "images/mouse1.jpg",
        id: 6,
        category: "mouse"
    },
     {
        name: "Logitech G500",
        price: "RS10500",
        image: "images/mouse2.jpg",
        id: 7,
        category: "mouse"
    },
    {
        name: "Razer DeathAdder",
        price: "RS13000",
        image: "images/mouse3.jpg",
        id: 8,
        category: "mouse"
    },
    // keyboards

    {
        name: "PhilcoGaming",
        price: "RS8000",
        image: "images/kb.jpg",
        id: 9,
        category: "keyboard"
    },
    {
        name: "Bloody B500N ",
        price: "RS9000",
        image: "images/kb1.jpg",
        id: 10,
        category: "keyboard"
    },
    {
        name: "PhilcoGaming",
        price: "RS5000",
        image: "images/kb2.jpg",
        id: 11,
        category: "keyboard"
    },
    {
        name: "Msi MAG",
        price: "RS40000",
        image: "images/m1.jpg",
        id: 12,
        category: "monitor"
    },
    {
        name: "Msi OPTIX",
        price: "RS35000",
        image: "images/m2.jpg",
        id: 13,
        category: "monitor"
    },
     {
        name: "ASUS TUF GAMING",
        price: "RS55000",
        image: "images/m3.jpg",
        id: 14,
        category: "monitor"
    },

];

